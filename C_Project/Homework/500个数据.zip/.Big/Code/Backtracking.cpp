#include <bits/stdc++.h> 
#include <time.h>       // 包含时间库头文件，用于计时
using namespace std;
#define Maxn 100  // 定义一个常量，表示数组的最大容量
int n;          // 物品的总数
int c;          // 每个箱子的容量
int bestNum;    // 最少的箱子数量
int curNum;     // 当前使用的箱子数量
int curC[Maxn]; // 当前每个箱子的剩余容量

// 回溯算法函数
// 参数：s 是物品大小数组，i 是当前考虑的物品索引
void Backtracking(int *s, int i) {
    // 当所有物品都已考虑时，更新最少箱子数量
    if (i == n) {
        if (curNum < bestNum) {  // 如果当前使用的箱子数量更少，更新最少箱子数量
            bestNum = curNum;
        }
    } else {
        // 遍历当前使用的箱子
        for (int j = 0; j < curNum; j++) {
            // 如果当前箱子剩余容量足够容纳当前物品
            if (curC[j] >= s[i]) {
                // 将物品放入当前箱子，并递归搜索下一物品
                curC[j] -= s[i];
                Backtracking(s, i + 1);
                // 恢复当前箱子状态
                curC[j] += s[i];
            }
        }
        // 如果当前使用的箱子数量小于最少箱子数量
        if (curNum < bestNum) {
            // 将当前物品放入一个新的箱子，并递归搜索下一物品
            curC[curNum] = c - s[i];  // 初始化新箱子的剩余容量
            curNum++;               // 使用一个新的箱子
            Backtracking(s, i + 1);
            curNum--;               // 回退使用箱子的数量
        }
    }
}

int main() {
    // 定义物品大小数组
    int s[] ={40, 30, 20, 10, 15, 25, 5, 35, 10, 20, 30, 15, 25, 35, 10, 20, 30, 15, 25, 35};
    // 计算物品数量
    n = sizeof(s) / sizeof(s[0]);
    // 设置箱子容量
    c = 50;
    // 定义时间变量
    clock_t start, end;
    double time_used;
    // 记录开始时间
    start = clock();
    // 初始化每个箱子的剩余容量
    for (int i = 0; i < n; i++) {
        curC[i] = c;
    }
    // 初始化最少箱子数量
    bestNum = n;
    // 初始化当前使用的箱子数量
    curNum = 0;
    // 执行回溯算法
    Backtracking(s, 0);
    // 记录结束时间
    end = clock();
    // 计算运行时间
    time_used = (double)(end - start) / CLOCKS_PER_SEC;
    cout<<"最少需要"<<bestNum<<"个箱子"<<endl;
    cout<<"运行时间为"<<time_used<<"秒"<<endl;
    return 0;
}
//能够找到最优解